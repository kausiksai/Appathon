package com.gokul.cropdetector;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

public class CropSuggestionDisplayActivity extends AppCompatActivity {

    static ProgressDialog progressDialog;
    String JSON_STRING;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_crop_suggestion_display);

        progressDialog = new ProgressDialog(CropSuggestionDisplayActivity.this,R.style.AppCompatAlertDialogStyle);
        progressDialog.setMessage("Fetching Details from Server! Please Wait...");
        progressDialog.setCancelable(false);
        progressDialog.show();
        new AnnualStateConventionBackgroundTask().execute();
    }

    class AnnualStateConventionBackgroundTask extends AsyncTask<String,Void,String> {

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected String doInBackground(String... params) {

            {
                String json_url = "http://sonaplaystore.xyz/iste/crop_suggestion.php";

                try {
                    URL url = new URL(json_url);
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    httpURLConnection.setRequestMethod("POST");
                    httpURLConnection.setDoOutput(true);
                    httpURLConnection.setDoInput(true);
                    OutputStream outputStream = httpURLConnection.getOutputStream();
                    BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream,"UTF-8"));
                    String data = URLEncoder.encode("key","UTF-8")+"="+URLEncoder.encode("a","UTF-8");
                    bufferedWriter.write(data);
                    bufferedWriter.flush();
                    bufferedWriter.close();
                    outputStream.close();
                    InputStream inputStream = httpURLConnection.getInputStream();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                    StringBuilder stringBuilder = new StringBuilder();

                    while((JSON_STRING=bufferedReader.readLine())!=null)
                    {
                        stringBuilder.append(JSON_STRING+"\n");
                    }
                    bufferedReader.close();
                    inputStream.close();
                    httpURLConnection.disconnect();
                    return stringBuilder.toString().trim();


                } catch (MalformedURLException e) {
                    e.printStackTrace();
                    return e.getMessage();
                } catch (IOException e) {
                    e.printStackTrace();
                    return e.getMessage();

                }

            }

        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(String result) {

            String a=result;
            JSONObject jsonObject;
            JSONArray jsonArray;

            if (a==null) {
                Toast.makeText(getApplicationContext(),"Sorry..! No Data Found..!",Toast.LENGTH_LONG).show();
            }
            else {

                ListView listView = (ListView) findViewById(R.id.listview);
                final ArrayList<String> arrayList = new ArrayList<>();

                try {
                    jsonObject = new JSONObject(a);
                    jsonArray = jsonObject.getJSONArray("server_response");

                    progressDialog.dismiss();

                    for(int i=0;i<jsonArray.length();i++) {

                        JSONObject JO = jsonArray.getJSONObject((i));
                        String pesticides = JO.getString("pesticides");
                        String soil_type = JO.getString("soil_type");
                        String crop = JO.getString("crop");
                        String water_level = JO.getString("water_level");
                        String moisture = JO.getString("moisture");

                        arrayList.add("Your Crop = " + crop);
                        arrayList.add("Soil Type = " + soil_type);
                        arrayList.add("Recommended Pesticides = " + pesticides);
                        arrayList.add("Recommended Water Level = " + water_level);
                        arrayList.add("Recommended Moisture = " + moisture);

                    }

                    ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>
                            (getApplicationContext(), android.R.layout.simple_list_item_1, arrayList){
                        @Override
                        public View getView(int position, View convertView, ViewGroup parent){
                            View view = super.getView(position, convertView, parent);
                            TextView tv = (TextView) view.findViewById(android.R.id.text1);

                            tv.setTextColor(Color.BLACK);
                            return view;
                        }
                    };
                    listView.setAdapter(arrayAdapter);

                } catch (JSONException e) {

                    if(!isOnline())
                    {
                        Toast.makeText(getApplicationContext(),"You are Not Connected to Internet! Turn on your Mobile Data or Connect to SONA-WIFI",Toast.LENGTH_LONG).show();
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(),"Your URN is Incorrect or Our Servers may be Down! Try again in a While"+a,Toast.LENGTH_LONG).show();
                    }
                    e.printStackTrace();
                }

            }

        }
    }

    protected boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager)getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnectedOrConnecting()) {
            return true;
        } else {
            return false;
        }
    }
}
