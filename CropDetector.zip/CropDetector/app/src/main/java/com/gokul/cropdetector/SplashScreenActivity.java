package com.gokul.cropdetector;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

public class SplashScreenActivity extends AppCompatActivity {

    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash_screen);

        textView = findViewById(R.id.textview);

        android.view.animation.Animation animation = AnimationUtils.loadAnimation(this,R.anim.myanimation);
        textView.setAnimation(animation);

        final Intent intent = new Intent(this,MainActivity.class);

        Thread thread = new Thread() {
            public void run(){
                try {
                    sleep(3000);
                }
                catch (InterruptedException e) {
                    e.printStackTrace();
                }
                finally {
                    startActivity(intent);
                    overridePendingTransition(R.anim.entry,R.anim.exit);
                    finish();
                }
            }
        };
        thread.start();
    }
}
