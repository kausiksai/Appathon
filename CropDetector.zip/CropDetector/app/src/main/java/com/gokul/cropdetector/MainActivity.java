package com.gokul.cropdetector;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;

public class MainActivity extends AppCompatActivity {

    CardView crop_detector,crop_suggestion,analysis;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);

        crop_detector = findViewById(R.id.crop_detector);
        crop_suggestion = findViewById(R.id.crop_suggestion);
        analysis = findViewById(R.id.analysis);

        crop_detector.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,CropDetectorActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.entry,R.anim.exit);
                finish();
            }
        });

        crop_suggestion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,CropSuggestionActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.entry,R.anim.exit);
                finish();
            }
        });

        analysis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,AnalysisActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.entry,R.anim.exit);
                finish();
            }
        });
    }
}
