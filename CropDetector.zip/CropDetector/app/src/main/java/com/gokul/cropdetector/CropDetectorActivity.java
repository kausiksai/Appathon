package com.gokul.cropdetector;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

public class CropDetectorActivity extends AppCompatActivity {

    EditText editText_soil_type;
    Button btn_search;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_crop_detector);

        editText_soil_type = findViewById(R.id.edittext_soil_type);
        btn_search = findViewById(R.id.btn_search);

        btn_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String soil = editText_soil_type.getText().toString();

                if (TextUtils.isEmpty(soil)) {
                    Toast.makeText(getApplicationContext(),"Please Enter the soil type mentioned below...",Toast.LENGTH_LONG).show();
                }

                Intent intent = new Intent(CropDetectorActivity.this, CropDetectorDisplayActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.entry, R.anim.exit);
                finish();


            }
        });


    }
}

