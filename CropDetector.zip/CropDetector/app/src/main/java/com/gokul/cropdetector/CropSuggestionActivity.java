package com.gokul.cropdetector;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CropSuggestionActivity extends AppCompatActivity {

    EditText editText_temperature, editText_soil_type;
    Button btn_search;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_crop_suggestion);

        editText_temperature = findViewById(R.id.edittext_temperature);
        editText_soil_type = findViewById(R.id.edittext_soil_type);
        btn_search = findViewById(R.id.btn_search);

        btn_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String crop,soil;

                crop = editText_temperature.getText().toString();
                soil = editText_soil_type.getText().toString();

                if (TextUtils.isEmpty(crop)) {
                    Toast.makeText(getApplicationContext(),"Please Enter the crop mentioned below...",Toast.LENGTH_LONG).show();
                }

                if (TextUtils.isEmpty(soil)) {
                    Toast.makeText(getApplicationContext(),"Please Enter the soil type mentioned below...",Toast.LENGTH_LONG).show();
                }


                    Intent intent = new Intent(CropSuggestionActivity.this, CropSuggestionDisplayActivity.class);
                    startActivity(intent);
                    overridePendingTransition(R.anim.entry, R.anim.exit);
                    finish();



            }
        });
    }
}
